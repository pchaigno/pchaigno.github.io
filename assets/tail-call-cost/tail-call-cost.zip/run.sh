#!/bin/bash
set -e

nb_tc=$1
repeat=$2

clang -O2 -Wall -target bpf -I/usr/include/x86_64-linux-gnu -c -o kern.o kern.c
sudo sh -c 'rm /sys/fs/bpf/action_prog* /sys/fs/bpf/map_progs 2>/dev/null' || true
sleep 0.1
sudo bpftool prog loadall kern.o /sys/fs/bpf/
sudo bpftool map pin name progs /sys/fs/bpf/map_progs
# map_id=$(sudo bpftool map show -j | jq '.[] | select( .type == "prog_array" and .owner_prog_type == "sched_act" ) | .id')
for (( i=1; i<=$nb_tc; i++ )); do
	sudo bpftool map update pinned /sys/fs/bpf/map_progs key $i 0 0 0 value pinned "/sys/fs/bpf/action_prog$i"
done
sudo bpftool prog run pinned /sys/fs/bpf/action_prog0 data_in data.bin repeat $repeat
